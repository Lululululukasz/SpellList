int final _strength, _dexterity, _constitution, _intelligence, _wisdom, _charisma;

